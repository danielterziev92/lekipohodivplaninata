create function pg_relation_size(regclass) returns bigint
    strict
    parallel safe
    cost 1
    language sql
RETURN pg_relation_size($1, 'main'::text);

comment on function pg_relation_size(regclass, unknown) is 'disk space usage for the main fork of the specified table or index';

alter function pg_relation_size(regclass, unknown) owner to postgres;

